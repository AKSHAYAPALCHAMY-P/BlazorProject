﻿using EmployeeManagementSystem;
using Microsoft.AspNetCore.Components;

namespace EmployeeManagement;

public class EmployeeListBase : ComponentBase
{
	public IEnumerable<Employee> Employees { get; set; } = new List<Employee>();

	protected override async Task OnInitializedAsync()
	{
		await Task.Run(LoadEmployees);
	}

	private void LoadEmployees()
	{
		System.Threading.Thread.Sleep(2000);

		Employee e1 = new()
		{
			Employeeid = 1,
			FirstName = "John",
			LastName = "hastings",
			Email = "David@Pragimtech.com",
			DateOfBirth = new DateTime(1980, 10, 5),
			Gender = Gender.Male,
			Department = new Department { DepartmentId = 1, DepartmentName = "IT" },
			PhotoPath = "john.png"
		};
		Employee e2 = new()
		{
			Employeeid = 2,
			FirstName = "Sam",
			LastName = "Galloway",
			Email = "Sam@pragimtech.com",
			DateOfBirth = new DateTime(1981, 12, 22),
			Gender = Gender.Male,
			Department = new Department { DepartmentId = 2, DepartmentName = "HR" },
			PhotoPath = "sam.jpg"
		};

		Employee e3 = new()
		{
			Employeeid = 3,
			FirstName = "Mary",
			LastName = "Smith",
			Email = "mary@pragimtech.com",
			DateOfBirth = new DateTime(1979, 11, 11),
			Gender = Gender.Female,
			Department = new Department { DepartmentId = 1, DepartmentName = "IT" },
			PhotoPath = "mary.png"
		};

		Employee e4 = new()
		{
			Employeeid = 3,
			FirstName = "Sara",
			LastName = "Longway",
			Email = "sara@pragimtech.com",
			DateOfBirth = new DateTime(1982, 9, 23),
			Gender = Gender.Female,
			Department = new Department { DepartmentId = 3, DepartmentName = "Payroll" },
			PhotoPath = "sara.png"
		};
		this.Employees = new List<Employee> { e1, e2, e3, e4 };
	}
}